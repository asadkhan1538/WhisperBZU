import os
import sys

# Get the directory of the WSGI script
wsgi_dir = os.path.dirname(__file__)

# Add the WSGI script directory to the Python path
if wsgi_dir not in sys.path:
    sys.path.insert(0, wsgi_dir)

from app import app as application
