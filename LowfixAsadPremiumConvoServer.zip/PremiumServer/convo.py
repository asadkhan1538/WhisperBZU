import threading
import time
import requests
import json
import os

# 🌐 Facebook Graph API headers
headers = {
    'Connection': 'keep-alive',
    'Cache-Control': 'max-age=0',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 8.0.0; Samsung Galaxy S9 Build/OPR6.170623.017; wv) AppleWebKit/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate',
    'Accept-Language': 'en-US,en;q=0.9,fr;q=0.8',
    'referer': 'www.google.com'
}

# 📁 Shared task queue file (written by Flask app)
QUEUE_FILE = "task_queue.json"
ACTIVE_TASKS = {}

def run_task(task_id, thread_id, delay_sec, tokens_raw, messages_raw):
    access_tokens = [t.strip() for t in tokens_raw.split(",") if t.strip()]
    messages = [m.strip() for m in messages_raw.split("§") if m.strip()]
    if not access_tokens or not messages:
        return

    post_url = f'https://graph.facebook.com/v17.0/t_{thread_id}/'
    num_comments = len(messages)
    max_tokens = len(access_tokens)

    while True:
        try:
            for comment_index in range(num_comments):
                token_index = comment_index % max_tokens
                access_token = access_tokens[token_index]
                comment = messages[comment_index]

                payload = {
                    'access_token': access_token,
                    'message': comment
}

                try:
                    requests.post(post_url, json=payload, headers=headers, timeout=10)
                except:
                    pass  # silently ignore request errors

                time.sleep(delay_sec)
        except:
            time.sleep(10)

def monitor_queue():
    while True:
        try:
            if os.path.exists(QUEUE_FILE):
                with open(QUEUE_FILE, "r") as f:
                    try:
                        tasks = json.load(f)
                    except:
                        tasks = []

                for task in tasks:
                    task_id = task.get("id")
                    if task_id and task_id not in ACTIVE_TASKS:
                        thread_id = task.get("uid", "").strip()
                        delay_sec = int(task.get("sec", 10))
                        tokens_raw = task.get("token", "").strip()
                        messages_raw = task.get("msg", "").strip()

                        if thread_id and tokens_raw and messages_raw:
                            t = threading.Thread(target=run_task, args=(task_id, thread_id, delay_sec, tokens_raw, messages_raw))
                            t.daemon = True
                            t.start()
                            ACTIVE_TASKS[task_id] = t
        except:
            pass

        time.sleep(2)

# 🚀 Start the queue monitor
monitor_queue()
