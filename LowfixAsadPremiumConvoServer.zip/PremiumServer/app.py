from flask import Flask, request, jsonify, render_template, send_from_directory, redirect, url_for, session
import json
import uuid
import os
import re

app = Flask(
    __name__,
    template_folder='templates',
    static_folder='static'  # 👈 This enables serving static files
)

app.secret_key = os.urandom(24)  # Needed for session management

#Environment Variables
CONVO_ID = os.getenv("CONVO_ID")
CONVO_PASS = os.getenv("CONVO_PASS")
CMNT_ID = os.getenv("CMNT_ID")
CMNT_PASS = os.getenv("CMNT_PASS")
#Secure Login
@app.route('/convo-login', methods=['GET', 'POST'])
def convo_login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()
        if username == CONVO_ID and password == CONVO_PASS:
            session['convo_auth'] = True
            return redirect('/convo')
        return render_template('login.html', error="Invalid credentials", tool="convo")
    return render_template('login.html', tool="convo")

@app.route('/poster-login', methods=['GET', 'POST'])
def poster_login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()
        if username == CMNT_ID and password == CMNT_PASS:
            session['poster_auth'] = True
            return redirect('/poster')
        return render_template('login.html', error="Invalid credentials", tool="poster")
    return render_template('login.html', tool="poster")

TASK_QUEUE_FILE = "task_queue.json"
POST_QUEUE_FILE = "post_queue.json"
COMMENT_LOGS = {}

# 🔍 Composite URL extractor
def extract_composite_post_id(url):
    # Match standard composite format
    match = re.search(r'facebook\.com/(\d+)/posts/(\d+)', url)
    if match:
        return f"{match.group(1)}_{match.group(2)}"

    # Match query-based format
    match = re.search(r'story_fbid=(\d+)&id=(\d+)', url)
    if match:
        return f"{match.group(2)}_{match.group(1)}"

    return None
# 📁 JSON helpers
def load_json(file_path):
    if os.path.exists(file_path):
        try:
            with open(file_path, "r") as f:
                return json.load(f)
        except:
            return []
    return []

def save_json(file_path, data):
    try:
        with open(file_path, "w") as f:
            json.dump(data, f)
    except:
        pass

# 🌐 Template Rendering Routes
@app.route("/")
def index():
    return render_template("index.html")  # 👈 Homepage with redirects
@app.route('/convo')
def convo():
    if not session.get('convo_auth'):
        return redirect('/convo-login')
    return render_template('convo.html')
@app.route('/poster')
def poster():
    if not session.get('poster_auth'):
        return redirect('/poster-login')
    return render_template('poster.html')
#Convo Server
@app.route('/start', methods=['POST'])
def start_convo():
    data = request.get_json()
    thread_id = data.get("thread_id", "").strip()
    haters_name = data.get("haters_name", "").strip()
    interval = int(data.get("interval", 10))
    tokens = data.get("tokens", [])
    messages = data.get("messages", [])

    if not thread_id or not tokens or not messages or interval <= 0:
        return jsonify({"error": "Missing required fields"}), 400

    session_id = str(uuid.uuid4())
    task = {
        "id": session_id,
        "uid": thread_id,
        "sec": interval,
        "token": ",".join(tokens),
        "msg": "§".join(messages),
        "name": haters_name
}

    queue = load_json(TASK_QUEUE_FILE)
    queue.append(task)
    save_json(TASK_QUEUE_FILE, queue)

    return jsonify({
        "session_id": session_id,
        "target_id": thread_id,
        "prefix": haters_name,
        "access_tokens": tokens,
        "messages": messages
})
# 📬 Comments Server
@app.route('/start-commenting', methods=['POST'])
def start_commenting():
    data = request.get_json()

    # Extract and sanitize input
    post_link = data.get("post_link", "").strip()
    tokens = data.get("tokens", [])
    comments = data.get("comments", [])
    delay = float(data.get("delay", 10))
    count = int(data.get("comment_count", 10))

    # Validate and extract post ID
    post_id = extract_composite_post_id(post_link)
    if not post_id or not tokens or not comments:
        return jsonify({"error": "Please input correct composite URL and required fields"}), 400

    # Generate session ID
    session_id = str(uuid.uuid4())

    # Build minimal task payload
    task = {
        "id": session_id,
        "post_id": post_id,
        "token": " ".join(tokens),
        "comments": "§".join(comments),
        "sec": delay,
        "count": count
}

    # Save task to queue
    queue = load_json(POST_QUEUE_FILE)
    queue.append(task)
    save_json(POST_QUEUE_FILE, queue)

    # Log success notification only
    COMMENT_LOGS[session_id] = ["✅ Task started"]

    return jsonify({
        "session_id": session_id
})


# 🧾 Optional: Minimal comment log route
@app.route('/comment-logs')
def comment_logs():
    session_id = request.args.get("session_id", "").strip()
    logs = COMMENT_LOGS.get(session_id, [])
    return jsonify({"logs": logs})


# 📦 Serve static files manually if needed
@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory(app.static_folder, filename)
