import threading
import time
import requests
import json
import os

# Configuration
QUEUE_FILE = "post_queue.json"
LOG_DIR = "comment_logs"
ACTIVE_POSTS = {}

os.makedirs(LOG_DIR, exist_ok=True)

headers = {
    'User-Agent': 'Mozilla/5.0',
    'Accept': '*/*',
    'Connection': 'keep-alive'
}

def send_comment(post_id, comment, token):
    url = f"https://graph.facebook.com/v19.0/{post_id}/comments"
    payload = {
        "message": comment,
        "access_token": token
    }
    try:
        response = requests.post(url, data=payload, headers=headers, timeout=10)
        return response.status_code == 200
    except:
        return False

def run_post_task(task_id, post_id, comments, tokens, delay, count):
    sent_count = 0
    comment_index = 0
    token_index = 0
    token_failures = {token: 0 for token in tokens}

    while sent_count < count:
        comment = comments[comment_index]
        token = tokens[token_index]

        if token_failures[token] >= 5:
            token_index = (token_index + 1) % len(tokens)
            continue

        success = send_comment(post_id, comment, token)
        if not success:
            token_failures[token] += 1
            time.sleep(2)
            continue

        sent_count += 1
        comment_index = (comment_index + 1) % len(comments)
        token_index = (token_index + 1) % len(tokens)
        time.sleep(delay)

def monitor_post_queue():
    while True:
        try:
            if os.path.exists(QUEUE_FILE):
                with open(QUEUE_FILE, "r") as f:
                    try:
                        tasks = json.load(f)
                    except:
                        tasks = []

                new_tasks = []
                for task in tasks:
                    task_id = task.get("id")
                    if task_id and task_id not in ACTIVE_POSTS:
                        post_id = task.get("post_id", "").strip()
                        comments_raw = task.get("comments", "").strip()
                        tokens_raw = task.get("token", "").strip()
                        delay = float(task.get("sec", 10))
                        count = int(task.get("count", 10))

                        comments = [c.strip() for c in comments_raw.split("§") if c.strip()]
                        tokens = [t.strip() for t in tokens_raw.split() if t.strip()]
                        if not post_id or not comments or not tokens:
                            continue

                        t = threading.Thread(
                            target=run_post_task,
                            args=(task_id, post_id, comments, tokens, delay, count)
                        )
                        t.daemon = True
                        t.start()
                        ACTIVE_POSTS[task_id] = t
                    else:
                        new_tasks.append(task)

                with open(QUEUE_FILE, "w") as f:
                    json.dump(new_tasks, f, indent=2)
        except:
            pass

        time.sleep(2)

if __name__ == "__main__":
    monitor_thread = threading.Thread(target=monitor_post_queue)
    monitor_thread.daemon = True
    monitor_thread.start()

    while True:
        time.sleep(10)
